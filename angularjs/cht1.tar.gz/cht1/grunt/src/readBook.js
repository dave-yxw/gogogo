$(function() {
    //测试一下压缩和合并
    alert("This is for test!");
})