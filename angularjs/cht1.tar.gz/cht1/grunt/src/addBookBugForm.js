$(function() {
    alert("This is for test!");
})