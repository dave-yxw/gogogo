function reverse(name) {
    // if (name == 'AAA') return "BBB";
    return name.split("").reverse().join("");
}